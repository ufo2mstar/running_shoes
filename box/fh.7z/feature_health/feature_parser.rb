require_relative '../../utils/string_extension'
require 'gherkin/parser/parser'
require 'gherkin/formatter/json_formatter'
require 'stringio'
require 'multi_json'
require 'find'

module FeatureParser
  class Feature
    attr_reader :data, :tags, :scenarios, :name

    def initialize(filename)
      @data = feature_to_json(filename)[0]
      @scenarios = []
      @tags = []
      if @data
        @name = @data['name']
        (@data["elements"] || []).each{ |scenario_json| @scenarios += Scenario.parse(scenario_json, self) }
        (@data["tags"] || []).each{ |tag| @tags.push(tag["name"]) }
      end
    end

    def feature_to_json(filename)
      io = StringIO.new
      formatter = Gherkin::Formatter::JSONFormatter.new(io)
      parser = Gherkin::Parser::Parser.new(formatter)
      parser.parse(IO.read(filename), filename, 0)
      formatter.done
      return MultiJson.load(io.string)
    end

    def get_id
      other_id = []
      @tags.each do |tag|
        other_id.push(tag)
      end
      return other_id
    end

    def to_s
      "Feature: #{@name} "
    end
  end

  class Scenario
    attr_reader :data, :tags, :line, :filename, :steps, :name, :feature, :keyword

    def initialize(json, feature)
      @data = json
      @feature = feature
      @tags = []
      @line = @data["line"]
      @filename = @feature.data["uri"]
      @keyword = @data['keyword']
      @name = @data['name']
      @steps = @data.fetch('steps', []).sort_by { |info| info['line'] }.map{ |info| info['name'] }
      @tags = @data.fetch("tags", []).map{ |info| info['name'] }
    end

    def to_s
      "Scenario: #{@data["name"]} "
    end

    def get_id
      other_id = []
      @tags.each do |tag|
        other_id.push(tag)
      end
      for t in @feature.tags do
        other_id.push(t)
      end
      return other_id
    end

    def is_sid(tag)
      if tag =~ /@SID_\d{8}/
        return true
      else
        return false
      end
    end

    def unique_id
      @tags.each do |tag|
        if tag =~ /@SID_\d{8}/
          return tag
        end
      end
      return false
    end

    # @return [Array<Scenario>]
    def self.parse(json, feature)
      scenarios = []

      if  json['type'] == 'scenario_outline'
        examples = parse_examples(json)

        original_steps = json['steps']
        index = 0
        examples.each do |example|
          new_steps = original_steps.map do |step|
            new_name = step['name'].clone
            example.each { |key, value| new_name.gsub!("<#{key}>", value) }
            step.merge('name' => new_name)
          end
          new_json = json.merge(
              'steps' => new_steps,
              'type' => 'scenario',
              'keyword' => 'Scenario'
          )
          new_json.delete('examples')
          new_json['tags'] = new_json.fetch('tags', []).map{|info| info['name'] =~ /@SID_\d+/ ? info.merge('name' => "#{info['name']}.#{index}") : info }
          index += 1
          scenarios << Scenario.new(new_json, feature)
        end
      else
        scenarios << Scenario.new(json, feature)
      end
      return scenarios
    end

    # @return [Array<Hash>] [{header1: value, header2: value}, {...}]
    def self.parse_examples(json)
      examples = []
      headers = json['examples'].first['rows'].delete_at(0)['cells']
      json['examples'].first['rows'].each do |row|
        example = {}
        headers.each_with_index do |header, index|
          example[header] = row['cells'][index]
          examples << example
        end
      end
      return examples
    end

  end

  class Parser
    def initialize
    end

    def parse_directory(directory)
      files = []
      Find.find(directory) do |path|
        files.push(path) if path =~ /.*\.feature/
      end
      return files
    end

    def parse_feature_file(file)
      feature = Feature.new(file)
      #feature.get_id
      return feature
    end

  end
end
