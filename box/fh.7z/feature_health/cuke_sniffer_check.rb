require 'cuke_sniffer'

####Get some info on where we are checking
DIRECTORY = "POWERSPORTS"
puts "\n\n*********************************************************************************"
puts "The default directory is #{DIRECTORY}, would you like to change? (ENTER to skip)?: "
input = gets.strip.upcase
DIRECTORY = input if input.size > 0
puts "Checking in directory: #{DIRECTORY}"


####Set up our expectations based on where we are looking at

if DIRECTORY == "NIAX"
  PAGE_TAGS = ["@pni_page", "@vehicle_page", "@driver_page", "@general_information_page", "@coverages_page"]
elsif DIRECTORY == "POWERSPORTS"
  PAGE_TAGS = ["@pni_page", "@vehicle_page", "@driver_page", "@general_information_page", "@coverages_page"]
end

PRIORITY_TAGS = ["@low_priority", "@medium_priority", "@high_priority", "@critical_priority"]
FREQUENCY_TAGS = ["@nightly", "@weekly", "@monthly", "@manual"]
VALIDATION_TAGS = ["@value_retention", "@input_fields", "@input_validation", "@static_text"]

#Use this if you want to run JUST ONE RULE!
#RUN_ONE_RULE = :sid_tag
RUN_ONE_RULE = nil


#This modifies the object defined in rule_config.rb
def modify_rules

  ##########################
  ###Implementation words###
  ##########################
  bad_words = ["site", "url", "drop down", "dropdown", "click", "clicks",
               "text box", "radio button", "check box","xml", "window",
               "pop up", "pop-up", "screen", "database", "DB", "fragment"]
  CukeSniffer::RuleConfig::RULES[:implementation_word][:words] = bad_words


  ####################
  ###Too Many Steps###
  ####################
  CukeSniffer::RuleConfig::RULES[:too_many_steps] = {
      :enabled => true,
      :phrase => "{class} with too many steps.",
      :score => CukeSniffer::RuleConfig::WARNING,
      :max => 15,
      :targets => ["Scenario", "Background"],
      :reason => lambda { |scenario, rule| scenario.steps.count > rule.conditions[:max]}
  }

  ####################
  ###Lots of Steps ###
  ####################
  CukeSniffer::RuleConfig::RULES[:many_steps] = {
      :enabled => true,
      :phrase => "{class} with many steps.",
      :score => CukeSniffer::RuleConfig::INFO,
      :max => 10,
      :targets => ["Scenario", "Background"],
      :reason => lambda { |scenario, rule| scenario.steps.count > rule.conditions[:max]}
  }

  ########################
  ###Out of order steps###
  ########################
  CukeSniffer::RuleConfig::RULES[:out_of_order_steps][:reason] = lambda { |scenario, rule|
    step_order = scenario.get_step_order
    ["But", "*", "And"].each { |type| step_order.delete(type) }

    order_correct = true
    order_correct=false if step_order[0] != "Given"
    order_correct=false unless step_order.size > 1 and step_order[1..-1].size % 2 == 0
    if order_correct
      step_order[1..-1].each_with_index do |item, index|
        word = index%2==0 ? "When" : "Then"
        order_correct=false if item != word
      end
    end
    scenario.store_rule(rule) unless order_correct
  }

  #####################################
  ###Same tag on feature as scenario###   //Cuke sniffer bug fix
  #####################################
  CukeSniffer::RuleConfig::RULES[:feature_same_tag] = {
      :enabled => true,
      :phrase => "{tag} tag appears on Feature.",
      :score => CukeSniffer::RuleConfig::WARNING,
      :targets => ["Feature"],
      :reason => lambda { |feature, rule|
        if(feature.scenarios.count >= 2)
          feature.scenarios.each do |scenario|
            feature.tags.each do |tag|
              if scenario.tags.include?(tag)
                feature.store_rule(rule, rule.phrase.gsub("{tag}", tag))
              end
            end
          end
        end}
  }

  ###############################
  ###Same tag on all scenarios###  //Cuke sniffer bug fix
  ###############################
  CukeSniffer::RuleConfig::RULES[:scenario_same_tag] = {
      #This rule was not working properly in cukesniffer, so it is updated here.
      :enabled => true,
      :phrase => "{tag} tag appears on all scenarios.",
      :score => CukeSniffer::RuleConfig::WARNING,
      :targets => ["Feature"],
      :reason => lambda { |feature, rule|
        unless feature.scenarios.empty?
          base_tag_list = feature.scenarios.first.tags.clone
          feature.scenarios.each do |scenario|
            base_tag_list_copy = base_tag_list.clone
            base_tag_list_copy.each do |tag|
              base_tag_list.delete(tag) unless scenario.tags.include?(tag)
            end
          end
          base_tag_list.each do |tag|
            feature.store_rule(rule, rule.phrase.gsub("{tag}", tag)) unless tag =~ /^@SID_\d+$/
          end
        end
      }
  }


  #########################
  ###SID tag on feature ###
  #########################
  CukeSniffer::RuleConfig::RULES[:feature_with_sid_tag] = {
      #This rule was not working properly in cukesniffer, so it is updated here.
      :enabled => true,
      :phrase => "{tag} TAG APPEARS ON FEATURE.",
      :score => 1000,
      :targets => ["Feature"],
      :reason => lambda { |feature, rule|
        unless feature.scenarios.empty?
          feature.tags.each do |tag|
            feature.store_rule(rule, rule.phrase.gsub("{tag}", tag)) if tag =~ /^@SID_\d+$/
          end
        end
      }
  }

  ###############################
  ###Scenario without SID tag ###
  ###############################
  CukeSniffer::RuleConfig::RULES[:sid_tag] = {
      :enabled => true,
      :phrase => "SCENARIO WITH NO SID TAG!.",
      :score => 1000,
      :targets => ["Scenario"],
      :reason => lambda { |scenario, rule|
        has_tag = false
        has_multiple_tags = false
        scenario.tags.each do |tag|
          has_multiple_tags = true if has_tag and tag =~ /^@SID_\d+$/
          has_tag = true if tag =~ /^@SID_\d+$/
        end
        scenario.store_rule(rule, "SCENARIO WITH MULTIPLE SID TAGS!.") if has_multiple_tags
        scenario.store_rule(rule) unless has_tag
      }
  }



  tag_check_lambda = lambda { |feature, rule|
    feature_special_tags = feature.tags & rule.conditions[:tags]
    if feature_special_tags.size > 1
      feature.store_rule(rule, "Feature has multiple #{rule.conditions[:type]} tags")
    end

    feature.scenarios.each do |scenario|
      scenario_special_tags = scenario.tags & rule.conditions[:tags]
      if scenario_special_tags.size > 1
        scenario.store_rule(rule, "Scenario has multiple #{rule.conditions[:type]} tags")
      end
      if scenario_special_tags.size > 0 and feature_special_tags.size > 0
        scenario.store_rule(rule, "Scenario and feature both have #{rule.conditions[:type]} tags")
      end
      if scenario_special_tags.size == 0 and feature_special_tags.size == 0
        scenario.store_rule(rule, "Scenario has no #{rule.conditions[:type]} tag!")
      end
    end
  }

  ####################################
  ###Scenario without Priority tag ###
  ####################################
  CukeSniffer::RuleConfig::RULES[:no_priority_tag] = {
      :enabled => true,
      :phrase => "Scenario with no priority tag.",
      :score => CukeSniffer::RuleConfig::WARNING,
      :tags => PRIORITY_TAGS,
      :type => "priority",
      :targets => ["Feature"],
      :reason => tag_check_lambda
  }

  ################################
  ###Scenario without Page tag ###
  ################################
  CukeSniffer::RuleConfig::RULES[:no_page_tag] = {
      :enabled => true,
      :phrase => "Scenario with no page tag.",
      :score => CukeSniffer::RuleConfig::WARNING,
      :tags => PAGE_TAGS,
      :type => "page",
      :targets => ["Feature"],
      :reason => tag_check_lambda
  }

  #####################################
  ###Scenario without frequency tag ###
  #####################################
  CukeSniffer::RuleConfig::RULES[:no_frequency_tag] = {
      :enabled => true,
      :phrase => "Scenario with no frequency tag.",
      :score => CukeSniffer::RuleConfig::WARNING,
      :tags => FREQUENCY_TAGS,
      :type => "frequency",
      :targets => ["Feature"],
      :reason => tag_check_lambda
  }

  ######################################
  ###Scenario without validation tag ###
  ######################################
  CukeSniffer::RuleConfig::RULES[:no_validation_tag] = {
      :enabled => true,
      :phrase => "Scenario with no validation tag.",
      :score => CukeSniffer::RuleConfig::WARNING,
      :tags => VALIDATION_TAGS,
      :type => "validation",
      :targets => ["Feature"],
      :reason => tag_check_lambda
  }

  ######################################
  ###Scenario with same description  ###
  ######################################



  #######################################
  ### Get rid of rules we do not want ###
  #######################################
  unwanted_rules = [:hook_not_in_hooks_file,
                    :numbers_in_description,
                    :hook_no_debugging,
                    :commas_in_description,
                    :long_name,
                    :multiple_given_when_then]

  print "\n\nRemoving these RULES:\n"
  unwanted_rules.each do |rule|
    print "\t#{rule}\n"
    CukeSniffer::RuleConfig::RULES[rule][:enabled] = false
  end


  if RUN_ONE_RULE
    CukeSniffer::RuleConfig::RULES.each_pair do |key, value|
      print "\t#{key}\n"
      unless key == RUN_ONE_RULE
        CukeSniffer::RuleConfig::RULES[key][:enabled] = false
      end
    end
  end

  print "\nUsing these RULES:\n"
  CukeSniffer::RuleConfig::RULES.each_pair do |key, value|
    if CukeSniffer::RuleConfig::RULES[key][:enabled]
      print "\t#{key}\n"
    end
  end

end


modify_rules
cuke_sniffer = CukeSniffer::CLI.new(
    {
        :features_location => "../../../#{DIRECTORY}/scenarios",
        :step_definitions_location => "../../step_definitions",
        :hooks_location => "../../../CORE",
        :no_catalog => false
    })
cuke_sniffer.output_html('my_file.html')
